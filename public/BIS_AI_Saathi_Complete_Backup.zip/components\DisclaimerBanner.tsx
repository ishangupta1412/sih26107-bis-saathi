import { AlertTriangle, ExternalLink } from 'lucide-react';

export default function DisclaimerBanner() {
  return (
    <div className="sticky top-0 z-50 w-full border-b border-amber-200 bg-amber-50 px-4 py-2">
      <div className="mx-auto flex max-w-5xl items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs text-amber-700">
          <AlertTriangle className="h-3.5 w-3.5 flex-shrink-0" />
          <span>
            <strong>Hackathon prototype — not official BIS guidance.</strong> Verify all information at{' '}
            <a
              href="https://www.bis.gov.in"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-medium hover:text-amber-900"
            >
              bis.gov.in
            </a>{' '}
            before making compliance decisions.
          </span>
        </div>
        <a
          href="https://www.bis.gov.in"
          target="_blank"
          rel="noopener noreferrer"
          className="hidden sm:flex flex-shrink-0 items-center gap-1 rounded bg-amber-100 px-2 py-1 text-xs font-medium text-amber-800 hover:bg-amber-200 transition-colors"
        >
          Official BIS <ExternalLink className="h-3 w-3" />
        </a>
      </div>
    </div>
  );
}
