import { NextRequest, NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase';

export const dynamic = 'force-dynamic';

// ISI license: CM/L- followed by 7-10 digits
const ISI_REGEX = /^CM\/L-\d{7,10}$/i;
// CRS registration: R- followed by 8 digits
const CRS_REGEX = /^R-\d{8}$/i;

function validateFormat(licenseNumber: string): {
  valid: boolean;
  type: 'ISI' | 'CRS' | null;
  message: string;
} {
  const cleaned = licenseNumber.trim().toUpperCase();

  if (ISI_REGEX.test(cleaned)) {
    return { valid: true, type: 'ISI', message: 'Valid ISI Mark format (CM/L-XXXXXXX)' };
  }
  if (CRS_REGEX.test(cleaned)) {
    return { valid: true, type: 'CRS', message: 'Valid CRS format (R-XXXXXXXX)' };
  }

  return {
    valid: false,
    type: null,
    message: 'Invalid format. ISI Mark numbers look like CM/L-1234567. CRS numbers look like R-41012345.',
  };
}

export async function POST(req: NextRequest) {
  try {
    const { licenseNumber } = await req.json();

    if (!licenseNumber) {
      return NextResponse.json({ error: 'License number is required' }, { status: 400 });
    }

    const cleaned = licenseNumber.trim().toUpperCase();
    const formatCheck = validateFormat(cleaned);

    if (!formatCheck.valid) {
      return NextResponse.json({
        found: false,
        formatValid: false,
        message: formatCheck.message,
        officialLink: 'https://www.bis.gov.in',
        bisCARENote: 'For official verification, use the BIS CARE app or visit bis.gov.in',
      });
    }

    // Query mock database
    const supabase = createServiceClient();
    const { data, error } = await supabase
      .from('licenses_mock')
      .select('*')
      .ilike('license_number', cleaned)
      .single();

    if (error || !data) {
      return NextResponse.json({
        found: false,
        formatValid: true,
        licenseType: formatCheck.type,
        message: `No record found for ${cleaned} in the demo dataset. This does not mean the license is invalid — this is a prototype with limited seeded data.`,
        officialLink: 'https://www.bis.gov.in',
        bisCARENote: 'For official verification, use the BIS CARE app or search at bis.gov.in',
      });
    }

    return NextResponse.json({
      found: true,
      formatValid: true,
      licenseType: formatCheck.type,
      license: {
        license_number: data.license_number,
        holder_name: data.holder_name,
        product_name: data.product_name,
        category: data.category,
        scheme_type: data.scheme_type,
        is_number: data.is_number,
        status: data.status,
        valid_till: data.valid_till,
        city: data.city,
        state: data.state,
      },
      disclaimer:
        'PROTOTYPE ONLY — This is demo data, not a live BIS database lookup. For legally binding verification, use the BIS CARE app or visit bis.gov.in.',
      officialLink: 'https://www.bis.gov.in',
    });
  } catch (error) {
    console.error('License check error:', error);
    return NextResponse.json({ error: 'Failed to check license' }, { status: 500 });
  }
}
