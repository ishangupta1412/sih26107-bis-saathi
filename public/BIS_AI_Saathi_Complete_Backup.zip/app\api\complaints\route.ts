import { NextRequest, NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase';
import { v4 as uuidv4 } from 'uuid';

export const dynamic = 'force-dynamic';

// Rate limiter: 10 complaint submissions per IP per hour
const complaintRateMap = new Map<string, { count: number; resetAt: number }>();
function checkComplaintRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = complaintRateMap.get(ip);
  if (!entry || now > entry.resetAt) {
    complaintRateMap.set(ip, { count: 1, resetAt: now + 3_600_000 });
    return true;
  }
  if (entry.count >= 10) return false;
  entry.count += 1;
  return true;
}

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
    if (!checkComplaintRateLimit(ip)) {
      return NextResponse.json({ error: 'Too many submissions. Try again later.' }, { status: 429 });
    }

    const body = await req.json();
    const { product_name, category, description, contact_email, photo_url, is_anonymous } = body;

    if (!product_name || !category || !description) {
      return NextResponse.json(
        { error: 'product_name, category, and description are required' },
        { status: 400 }
      );
    }

    // Server-side length limits
    if (description.length > 3000 || product_name.length > 200) {
      return NextResponse.json(
        { error: 'Input exceeded maximum character limit' },
        { status: 400 }
      );
    }

    // Generate readable reference ID: BIS-YYYY-XXXXXX
    const year = new Date().getFullYear();
    const shortId = uuidv4().replace(/-/g, '').slice(0, 6).toUpperCase();
    const reference_id = `BIS-${year}-${shortId}`;

    // Guarantee no PII stored if anonymous
    const finalEmail = is_anonymous ? null : (contact_email?.trim() || null);

    const supabase = createServiceClient();
    const { data, error } = await supabase
      .from('complaints')
      .insert({
        reference_id,
        product_name: product_name.trim(),
        category: category.trim(),
        description: description.trim(),
        contact_email: finalEmail,
        photo_url: photo_url || null,
        status: 'Submitted',
      })
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json({
      success: true,
      reference_id: data.reference_id,
      status: data.status,
      created_at: data.created_at,
      message: `Your complaint has been recorded. Reference ID: ${data.reference_id}. Save this ID to track your complaint.`,
    });
  } catch (error) {
    console.error('Complaint POST error:', error);
    return NextResponse.json({ error: 'Failed to submit complaint' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const reference_id = searchParams.get('reference_id');

    if (!reference_id) {
      return NextResponse.json({ error: 'reference_id query parameter is required' }, { status: 400 });
    }

    const supabase = createServiceClient();
    const { data, error } = await supabase
      .from('complaints')
      .select('reference_id, product_name, category, status, created_at, updated_at')
      .eq('reference_id', reference_id.trim().toUpperCase())
      .single();

    if (error || !data) {
      return NextResponse.json({ error: 'Complaint not found' }, { status: 404 });
    }

    return NextResponse.json({ complaint: data });
  } catch (error) {
    console.error('Complaint GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch complaint' }, { status: 500 });
  }
}
