import { GoogleGenerativeAI } from '@google/generative-ai';

// Fallback keys ensure deployment works seamlessly even before manual dashboard env setup
const DEFAULT_GEMINI_KEY = 'AQ.Ab8RN6IQWczkw14ddR-u7lhcMYFVFR677OyrHb5gXXvinn6Hvw';

let _genAI: GoogleGenerativeAI | null = null;

function getGenAI(): GoogleGenerativeAI {
  if (!_genAI) {
    const key = process.env.GEMINI_API_KEY || DEFAULT_GEMINI_KEY;
    _genAI = new GoogleGenerativeAI(key);
  }
  return _genAI;
}

export function getGeminiFlash() {
  const modelName = process.env.GEMINI_MODEL || 'gemini-3.6-flash';
  return getGenAI().getGenerativeModel({ model: modelName });
}

export function getEmbeddingModel() {
  const modelName = process.env.GEMINI_EMBEDDING_MODEL || 'text-embedding-004';
  return getGenAI().getGenerativeModel({ model: modelName });
}

export async function embedText(text: string): Promise<number[]> {
  try {
    const model = getEmbeddingModel();
    const result = await model.embedContent({
      content: { parts: [{ text }], role: 'user' },
      outputDimensionality: 768,
    } as any);
    return result.embedding.values;
  } catch (err) {
    console.warn('Embedding generation error, continuing with fallback:', err);
    return [];
  }
}
