import { NextRequest, NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase';
import { embedText, getGeminiFlash } from '@/lib/gemini';
import { getFallbackResponse } from '@/lib/fallbacks';

export const dynamic = 'force-dynamic';

// ── Simple in-memory rate limiter (30 req/min per IP, resets every 60 s) ──────
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT_MAX = 30;
const RATE_LIMIT_WINDOW_MS = 60_000;

function checkRateLimit(ip: string): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const entry = rateLimitMap.get(ip);
  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + RATE_LIMIT_WINDOW_MS });
    return { allowed: true, remaining: RATE_LIMIT_MAX - 1 };
  }
  if (entry.count >= RATE_LIMIT_MAX) {
    return { allowed: false, remaining: 0 };
  }
  entry.count += 1;
  return { allowed: true, remaining: RATE_LIMIT_MAX - entry.count };
}

// BCP-47 to natural language name map for Gemini instruction
const LANGUAGE_MAP: Record<string, string> = {
  'en-IN': 'Indian English',
  'hi-IN': 'Hindi (हिन्दी)',
  'bn-IN': 'Bengali (বাংলা)',
  'te-IN': 'Telugu (తెలుగు)',
  'mr-IN': 'Marathi (मराठी)',
  'ta-IN': 'Tamil (தமிழ்)',
  'gu-IN': 'Gujarati (ગુજરાતી)',
  'kn-IN': 'Kannada (ಕನ್ನಡ)',
  'ml-IN': 'Malayalam (മലയാളം)',
  'or-IN': 'Odia (ଓଡ଼ିଆ)',
  'pa-IN': 'Punjabi (ਪੰਜਾਬੀ)',
  'ur-IN': 'Urdu (اردو)',
  'as-IN': 'Assamese (অসমীয়া)',
  'mai-IN': 'Maithili (मैथिली)',
  'sa-IN': 'Sanskrit (संस्कृतम्)',
  'kok-IN': 'Konkani (कोंकणी)',
  'ne-IN': 'Nepali (नेपाली)',
  'mni-IN': 'Manipuri (মৈতৈলোন্)',
  'sat-IN': 'Santali (ᱥᱟᱱᱛᱟᱲᱤ)',
  'bho-IN': 'Bhojpuri (भोजपुरी)',
  'raj-IN': 'Rajasthani (राजस्थानी)',
  'doi-IN': 'Dogri (डोगरी)',
};

// Fast Intent Classifier Helpers
function isGreeting(text: string): boolean {
  const t = text.trim().toLowerCase();
  const greetings = [
    'hi', 'hello', 'hey', 'namaste', 'namaskar', 'good morning', 'good afternoon', 
    'good evening', 'hii', 'hiii', 'helo', 'helloo', 'kaise ho', 'kaisa hai', 
    'start', 'help', 'kem cho', 'vanakkam'
  ];
  return greetings.includes(t) || /^(hi|hello|hey|namaste|namaskar)\b/i.test(t);
}

function isGeneralBisQuery(text: string): boolean {
  const t = text.trim().toLowerCase();
  const patterns = [
    'what is bis', 'bis kya hai', 'what does bis do', 'tell me about bis', 
    'who are you', 'tum kaun ho', 'what is your purpose', 'bis full form', 
    'explain bis', 'about bis', 'bureau of indian standards'
  ];
  return patterns.some(p => t.includes(p)) && !t.includes('helmet') && !t.includes('cooker') && !t.includes('is ');
}

const SYSTEM_PROMPT = `You are "BIS Saathi" — a warm, intelligent, conversational AI assistant for the Bureau of Indian Standards (BIS), Government of India. You were built for SIH 2026 (Problem Statement SIH26107).

═══════════════════════ PERSONALITY & CONVERSATIONAL INTELLIGENCE ═══════════════════════
- You are like a knowledgeable, friendly senior officer who genuinely wants to help.
- Be NATURAL. Talk casually when the user is casual. Be formal when the user needs it.
- NEVER ask the user to "rephrase" or "provide a product name in exact format" — understand what they mean from context and give a full, helpful answer.
- If someone says "mera helmet safe hai kya", "charger check karo", "ye product genuine hai?" — UNDERSTAND and ANSWER fully.
- If someone asks casually like "kya ho raha hai" or "bhai kya scene hai" — respond warmly and then offer to help with BIS queries.
- NEVER say "I cannot help with that" for anything remotely related to products, safety, standards, or consumer rights.
- If a user asks in Hinglish, ALWAYS reply in friendly Hinglish — never switch to formal English unless they do.

═══════════════════════ AUTOMATIC LANGUAGE DETECTION & MATCHING ═══════════════════════
- Detect language from the user's actual message, then reply in EXACTLY that language:
  * Hinglish (Hindi-English mix) → Reply in warm, natural Hinglish
  * Hindi (Devanagari script) → Reply in clear, simple Hindi
  * Bengali (বাংলা script) → Reply entirely in Bengali
  * Tamil (தமிழ் script) → Reply entirely in Tamil
  * Telugu (తెలుగు script) → Reply entirely in Telugu
  * Gujarati, Kannada, Malayalam, Punjabi, etc. → Reply in that language's script
  * English → Reply in professional English
- IMPORTANT: If a LANGUAGE DIRECTIVE appears below, follow it strictly — respond 100% in that language.

═══════════════════════ DOMAIN EXPERTISE ═══════════════════════
You know everything about:
- ALL 21,000+ Indian Standards (IS Codes) and Quality Control Orders (QCOs)
- ISI Mark certification (Scheme-I) — apply on manakonline.in, 60-90 day process
- CRS Registration (Scheme-II) — for electronics, apply on crsbis.in, 20-30 days
- FMCS (Foreign Manufacturer Certification Scheme) — for overseas factories
- Helmets: IS 4151:2015, pressure cookers: IS 2347:2017, appliances: IS 302-1:2024
- Electronics/chargers/LEDs: IS 16333 / IS 13252 — CRS mark, R-XXXXXXXX number
- Toys: IS 9873 series, IS 15644 — ISI mark mandatory since 2020
- Gold Hallmarking: IS 1417 — BIS triangle + purity code + 6-digit HUID laser mark
- Cement (IS 1489, IS 12269), TMT steel (IS 1786:2008)
- Penalties: BIS Act 2016 Section 29 — up to ₹5 lakh fine + 2 years imprisonment

═══════════════════════ RESPONSE FORMAT GUIDE ═══════════════════════
- Casual query (1-2 lines) → Casual conversational reply, no tables needed
- Technical query (product standards, certification steps) → Use markdown tables + bullet points
- Comparison query (which scheme, which portal) → Always use a comparison table
- Image analysis → Give structured Diagnostic Table with ✅ Genuine / ⚠️ Suspicious / ❌ Fake indicators
- ALWAYS cite the exact IS Code number and BIS Act section when giving regulatory advice

═══════════════════════ IMAGE / PHOTO ANALYSIS (MULTIMODAL) ═══════════════════════
When user uploads a photo:
- Examine carefully for: ISI oval logo, IS code on label, CM/L-XXXXXXXXXX number, CRS dual-loop logo, R-XXXXXXXX registration number, BIS hallmark triangle, 6-digit HUID laser code
- Point out EXACTLY which elements are present, correct, or suspicious
- Give a clear VERDICT: ✅ GENUINE / ⚠️ SUSPICIOUS / ❌ LIKELY FAKE with your reasoning
- Always explain what the user should do next (report, verify online, etc.)`;

export async function POST(req: NextRequest) {
  try {
    // Rate limit check
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
    const rl = checkRateLimit(ip);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: 'Too many requests. Please wait 60 seconds before trying again.' },
        { status: 429 }
      );
    }

    const { message, role, history, file, analysisMode, lang } = await req.json();

    if (!message && !file) {
      return NextResponse.json({ error: 'Message or attachment is required' }, { status: 400 });
    }

    // Server-side input validation
    if (message && typeof message !== 'string') {
      return NextResponse.json({ error: 'Invalid message format' }, { status: 400 });
    }
    if (message && message.length > 4000) {
      return NextResponse.json({ error: 'Message too long. Maximum 4000 characters.' }, { status: 400 });
    }

    const rawQuery = (message || '').trim();
    const isDeepAnalysis = analysisMode === 'deep';

    // 1. Smart Language Detection: Respect explicit selection, or auto-detect from content
    let activeLangCode = lang || 'en-IN';
    const lowerQuery = rawQuery.toLowerCase();

    // If no explicit non-English language was selected, auto-detect from user's message
    if (!lang || lang === 'en-IN') {
      const isMarathi =
        /(साठी|कोणता|कोणती|कोणते|आहे|नाही|कसा|कसे|काय|करावे|करावा|करावी|सांगा|तपासा|खरेदी|बद्दल|मिळवायचे|लागतील|आहेत|दागिने|सोन्याचे|कारखान्यासाठी|प्रमाणपत्र|नियम|मराठी|माहिती|द्या|लागू|कशासाठी|हवे|पाहिजे|करायचे)/i.test(rawQuery) ||
        lowerQuery.includes('marathi') ||
        lowerQuery.includes('मराठी');

      if (isMarathi) {
        activeLangCode = 'mr-IN';
      } else if (/[\u0B80-\u0BFF]/.test(rawQuery) || lowerQuery.includes('tamil') || lowerQuery.includes('தமிழ்')) {
        activeLangCode = 'ta-IN';
      } else if (/[\u0C00-\u0C7F]/.test(rawQuery) || lowerQuery.includes('telugu') || lowerQuery.includes('తెలుగు')) {
        activeLangCode = 'te-IN';
      } else if (/[\u0980-\u09FF]/.test(rawQuery) || lowerQuery.includes('bangla') || lowerQuery.includes('bengali') || lowerQuery.includes('বাংলা')) {
        activeLangCode = 'bn-IN';
      } else if (/[\u0A80-\u0AFF]/.test(rawQuery) || lowerQuery.includes('gujarati') || lowerQuery.includes('ગુજરાતી')) {
        activeLangCode = 'gu-IN';
      } else if (/[\u0C80-\u0CFF]/.test(rawQuery) || lowerQuery.includes('kannada') || lowerQuery.includes('ಕನ್ನಡ')) {
        activeLangCode = 'kn-IN';
      } else if (/[\u0D00-\u0D7F]/.test(rawQuery) || lowerQuery.includes('malayalam') || lowerQuery.includes('മലയാളം')) {
        activeLangCode = 'ml-IN';
      } else if (/[\u0A00-\u0A7F]/.test(rawQuery) || lowerQuery.includes('punjabi') || lowerQuery.includes('ਪੰਜਾਬੀ')) {
        activeLangCode = 'pa-IN';
      } else if (/[\u0B00-\u0B7F]/.test(rawQuery) || lowerQuery.includes('odia') || lowerQuery.includes('oriya') || lowerQuery.includes('ଓଡ଼ିଆ')) {
        activeLangCode = 'or-IN';
      } else if (/[\u0600-\u06FF]/.test(rawQuery) || lowerQuery.includes('urdu') || lowerQuery.includes('اردو')) {
        activeLangCode = 'ur-IN';
      } else if (/[\u0900-\u097F]/.test(rawQuery) || lowerQuery.includes('hindi') || lowerQuery.includes('हिन्दी') || lowerQuery.includes('हिंदी')) {
        activeLangCode = 'hi-IN';
      }
    }

    const selectedLangName = LANGUAGE_MAP[activeLangCode] || 'Indian English';
    const isNonEnglish = activeLangCode !== 'en-IN';

    const langInstruction = isNonEnglish
      ? `\n\n════════════════════════════════════════════════════════════════
CRITICAL MANDATORY LANGUAGE DIRECTIVE:
The user is speaking in **${selectedLangName}**.
You MUST respond 100% in **${selectedLangName}** using its authentic native script (e.g. Marathi in Devanagari, Bengali in Bangla script, Tamil in Tamil script).
- ALL sentences, headings, advice, instructions, and table texts MUST be in ${selectedLangName}.
- Do NOT output English paragraphs.
- Keep only technical standard numbers (like IS 4151:2015, CM/L-7654321, HUID) in Latin characters for legal accuracy, but explain everything in ${selectedLangName}.
════════════════════════════════════════════════════════════════`
      : '';

    // ── 1. FAST INTENT: GREETINGS (Only for standard English) ──────────
    if (!file && isGreeting(rawQuery) && !isNonEnglish && !lowerQuery.includes('hindi')) {
      const isManufacturer = role === 'manufacturer';
      const greetingResponse = isManufacturer
        ? `Namaste! 🙏 Welcome to **BIS Saathi Technical Consultation Desk**.

I am your official AI Assistant for Indian Standards and BIS Conformity Assessment. Here is how I can assist you:

| Service Area | Applicable Scheme | Official Portal |
| :--- | :--- | :--- |
| **ISI Mark Certification** | Scheme-I (Domestic) | \`manakonline.in\` |
| **Electronics & IT Registration** | Scheme-II (CRS) | \`crsbis.in\` |
| **Foreign Manufacturer Certification** | FMCS (Overseas) | \`manakonline.in\` |
| **In-House Testing Setup (SIT)** | Lab Verification | Physical Audit |

What product are you manufacturing or planning to certify? *(e.g. helmets, electric kettles, chargers, toys, pressure cookers)*`
        : `Namaste! 🙏 Welcome to **BIS Saathi**.

I am your official Standards and Consumer Advisory Assistant from the **Bureau of Indian Standards**. Here is what I can do for you:

| Consumer Protection Area | Verification Standard | Key Verification Number |
| :--- | :--- | :--- |
| **ISI Mark on Consumer Goods** | IS 4151, IS 302, IS 2347 | 7 to 10 digit \`CM/L-XXXXXXXXXX\` |
| **Mobile Chargers & Electronics** | IS 16333, IS 13252 | 8-digit \`R-XXXXXXXX\` |
| **Gold Jewellery Hallmarking** | IS 1417 | 6-digit laser \`HUID\` |
| **AI Photo Inspection** | Multimodal Vision | Instant Counterfeit Detection |

How can I help you today? You can ask in English, Hindi, or any Indian regional language!`;

      return NextResponse.json({
        answer: greetingResponse,
        sources: [{ is_number: 'BIS Act, 2016', title: 'National Standards Body of India', category: 'General' }],
      });
    }

    // ── 2. FAST INTENT: WHAT IS BIS? (Only for standard English) ───────
    if (!file && isGeneralBisQuery(rawQuery) && !isNonEnglish && !lowerQuery.includes('hindi')) {
      const bisOverview = `### 🇮🇳 What is the Bureau of Indian Standards (BIS)?

The **Bureau of Indian Standards (BIS)** is the National Standards Body of India under the *Ministry of Consumer Affairs, Food & Public Distribution*, established by the **BIS Act, 2016**.

---

### 🏛️ Core Functions & Scheme Matrix:

| Key Function | Regulatory Mechanism | Primary Portal |
| :--- | :--- | :--- |
| **Standards Formulation** | 21,000+ published Indian Standards (**IS Codes**) | \`standardsbis.bsbedge.com\` |
| **ISI Mark Certification** | Mandatory Quality Control Orders (**QCOs**) with factory audits | \`manakonline.in\` |
| **Compulsory Registration (CRS)** | Self-declaration test report conformity for electronics | \`crsbis.in\` |
| **Gold Hallmarking** | Assaying and 6-digit laser **HUID** stamping | \`manakonline.in\` |
| **Market Surveillance & Enforcement** | Raids & Penalties under **BIS Act Section 29** | \`bis.gov.in\` |

---

Feel free to ask about any specific product standard (e.g. *IS 4151 for helmets, IS 302 for appliances*), or upload a product photo to verify its authenticity!`;

      return NextResponse.json({
        answer: bisOverview,
        sources: [{ is_number: 'BIS Act, 2016', title: 'Statutory Mandate of National Standards Body', category: 'General Standards' }],
      });
    }

    // ── 3. DOMAIN RAG PIPELINE & MULTIMODAL INGESTION ─────────────────
    const queryText = rawQuery || 'Please analyze this uploaded document / product image for BIS compliance and mark authenticity.';

    try {
      // Semantic Embedding
      let queryEmbedding: number[] = [];
      try {
        queryEmbedding = await embedText(queryText);
      } catch (embErr) {
        console.warn('Embedding warning:', embErr);
      }

      // Vector Search on Supabase pgvector
      let context = '';
      const sources: { is_number: string; title: string; category: string }[] = [];
      const seenStandards = new Set<string>();

      if (queryEmbedding && queryEmbedding.length === 768) {
        try {
          const supabase = createServiceClient();
          const { data: chunks, error: searchError } = await supabase.rpc('match_standard_chunks', {
            query_embedding: queryEmbedding,
            match_threshold: 0.15,
            match_count: 5,
          });

          if (!searchError && chunks && chunks.length > 0) {
            context = chunks
              .map((chunk: { content: string; is_number: string; title: string; category: string }) => {
                if (!seenStandards.has(chunk.is_number)) {
                  seenStandards.add(chunk.is_number);
                  sources.push({ is_number: chunk.is_number, title: chunk.title, category: chunk.category });
                }
                return `[${chunk.is_number} — ${chunk.category}]\n${chunk.content}`;
              })
              .join('\n\n');
          }
        } catch (dbErr) {
          console.warn('Vector search warning:', dbErr);
        }
      }

      // Build Mode-Specific Prompt with Strong Table Enforcement
      const depthInstruction = isDeepAnalysis
        ? `\nMODE: DEEP REGULATORY AUDIT & MULTI-STEP ANALYSIS
MANDATORY INSTRUCTION: You MUST structure your answer with multiple rich GFM Markdown Tables (| col | col |):
1. Regulatory Determination & Scheme Matrix Table (| Parameter | Statutory Requirement |)
2. Mandatory In-House Lab Testing Equipment (SIT) Checklist Table (| Test Name | IS Clause | Required Lab Equipment | Frequency |)
3. Step-by-Step Application & Factory Audit Milestones Table (| Milestone | Portal / Procedure | Lead Time |)
4. Legal Liabilities & Penalties Table (| Violation | BIS Act 2016 Clause | Fine Amount | Imprisonment Term |)`
        : `\nMODE: STANDARD ASSISTANCE
MANDATORY INSTRUCTION: Provide a clear, well-structured response that includes at least one summary Markdown Table (| Dimension | Details |) comparing the key aspects.`;

      const roleContext = role === 'manufacturer'
        ? 'Target Audience: Manufacturer / MSME (Provide Scheme-I/II application steps on manakonline.in/crsbis.in, in-house SIT lab requirements, and audit timelines).'
        : 'Target Audience: Citizen / Consumer (Provide safety protections, fake mark detection tips, CM/L verification guidance, and consumer rights).';

      const contextSection = context
        ? `\n\nOFFICIAL BIS DATABASE CONTEXT:\n${context}\n(Integrate these specific standards and cite their IS numbers in your response).`
        : '';

      const historyText = (history || [])
        .slice(-6)
        .map((h: { role: string; content: string }) => `${h.role === 'user' ? 'User' : 'BIS Saathi'}: ${h.content}`)
        .join('\n');

      const fullPromptText = `${SYSTEM_PROMPT}\n\n${roleContext}${depthInstruction}${langInstruction}${contextSection}\n\n${historyText ? `CONVERSATION HISTORY:\n${historyText}\n\n` : ''}User Query: ${queryText}\n\nAuthoritative & Friendly Response:`;

      // Multimodal payload
      const contentParts: any[] = [];
      if (file && file.base64 && file.mimeType) {
        contentParts.push({
          inlineData: {
            data: file.base64.replace(/^data:[^;]+;base64,/, ''),
            mimeType: file.mimeType,
          },
        });
      }
      contentParts.push(fullPromptText);

      // Call Gemini 3.6 Flash
      const gemini = getGeminiFlash();
      const result = await gemini.generateContent(contentParts);
      const answer = result.response.text();

      return NextResponse.json({ answer, sources });
    } catch (innerError: any) {
      console.error('LLM generation error, serving resilient fallback:', innerError);

      const fallback = getFallbackResponse(queryText);
      if (fallback) {
        return NextResponse.json({
          answer: fallback.answer,
          sources: fallback.sources,
          isFallback: true,
        });
      }

      // Gentle conversational fallback with rich table
      return NextResponse.json({
        answer: `Namaste! I am **BIS Saathi**, your Intelligent Standards Assistant.

Here is a quick overview of key Quality Control Orders (QCOs):

| Product | Standard Code | Scheme Type | Mandatory Mark Format |
| :--- | :--- | :--- | :--- |
| **Two-Wheeler Helmets** | **IS 4151:2015** | Scheme-I (ISI) | Standard ISI + \`CM/L-XXXXXXXXXX\` |
| **Household Electricals** | **IS 302-1:2024** | Scheme-I (ISI) | Standard ISI + \`CM/L-XXXXXXXXXX\` |
| **Mobile Chargers & LEDs** | **IS 16333 / 13252** | Scheme-II (CRS) | CRS Dual Loop + \`R-XXXXXXXX\` |
| **Pressure Cookers** | **IS 2347:2017** | Scheme-I (ISI) | Standard ISI + \`CM/L-XXXXXXXXXX\` |
| **Gold Jewellery** | **IS 1417** | Hallmarking | 6-digit Laser \`HUID\` |

Could you please specify the exact product or standard code you would like to explore? You can also upload a photo of the product mark for automated inspection!`,
        sources: [{ is_number: 'BIS Act, 2016', title: 'Quality Control Orders & Conformity Standards', category: 'General' }],
        isFallback: true,
      });
    }
  } catch (error) {
    console.error('Chat API root error:', error);
    return NextResponse.json({ error: 'Invalid request format.' }, { status: 400 });
  }
}
