export interface FallbackResponse {
  answer: string;
  sources: { is_number: string; title: string; category: string }[];
}

const EXTENDED_FALLBACKS: Record<string, FallbackResponse> = {
  helmet: {
    answer: `### 🪖 Two-Wheeler Helmets — IS 4151:2015

* **Mandatory Status:** Compulsory under the *Helmet for Riders of Two-Wheeler Motor Vehicles (Quality Control) Order, 2020*.
* **Certification Scheme:** **Scheme I (ISI Mark)** — requires factory audit and laboratory sample testing.
* **Mark Format:** Look for the **ISI Mark** with standard header \`IS 4151\` and a 7-digit license number \`CM/L-XXXXXXX\`.
* **Key Safety Tests:**
  1. **Impact Attenuation:** Shock absorption test at extreme temperatures (-10°C to +50°C).
  2. **Penetration Resistance:** Cone drop test to ensure shell does not pierce.
  3. **Retention System:** Chin strap dynamic load test to prevent helmet ejection during crashes.
* **How to Apply (Manufacturers):** Submit application on [manakonline.in](https://www.manakonline.in). Typical timeline is 60–90 days.
* **Statutory Warning:** Selling non-ISI helmets is punishable under Section 29 of the BIS Act, 2016 with fines up to ₹5 lakh and up to 2 years imprisonment.`,
    sources: [{ is_number: 'IS 4151:2015', title: 'Protective Helmets for Two-Wheeler Motor Vehicle Riders', category: 'Helmets & Headgear' }],
  },

  kettle_appliances: {
    answer: `### ⚡ Household Electrical Appliances & Kettles — IS 302-1 / IS 302-2-15

* **Applicable Standards:**
  * **IS 302 (Part 1):2024:** General electrical safety requirements (voltage up to 250V).
  * **IS 302-2-15:** Specific requirements for electric kettles, liquid heaters, and water boilers.
  * **IS 302-2-3:** Electric dry & steam irons.
* **Mandatory QCO:** Enforced under the *Safety of Household, Commercial and Similar Electrical Appliances QCO, 2026*.
* **Scheme:** **Scheme-I (ISI Mark)** — Factory audit + NABL lab testing.
* **Key Tests:** Protection against electric shock, leakage current, moisture resistance, and thermal cutout safety to prevent boiling dry.
* **Application Portal:** [manakonline.in](https://www.manakonline.in).`,
    sources: [
      { is_number: 'IS 302-1:2024', title: 'Safety of Household Electrical Appliances — General Requirements', category: 'Household Electrical' },
      { is_number: 'IS 302-2-15', title: 'Electric Kettles & Liquid Heaters Safety', category: 'Kitchen Appliances' },
    ],
  },

  charger_electronics: {
    answer: `### 📱 Mobile Chargers, Adapters & Electronics — CRS (Scheme II)

* **Applicable Standard:** **IS 16333 (Part 3) / IS 13252** under MeitY Compulsory Registration Order.
* **Scheme:** **Scheme II (CRS — Compulsory Registration Scheme)**.
* **Crucial Difference:** **NO factory inspection is required.** Only laboratory testing at a BIS-recognized NABL lab followed by online registration.
* **Mark Format:** Displays the official **CRS Registration Logo** with registration number \`R-XXXXXXXX\` (e.g. \`R-41012345\`).
* **Lead Time:** 20–30 working days via [crsbis.in](https://www.crsbis.in).`,
    sources: [{ is_number: 'IS 16333 / IS 13252', title: 'Mobile Phone Power Adapters & Information Technology Goods', category: 'Electronics & IT (CRS)' }],
  },

  toys: {
    answer: `### 🧸 Safety of Toys — IS 9873 / IS 15644

* **Mandatory QCO:** *Toys (Quality Control) Order, 2020*. Selling non-ISI toys in India is strictly illegal.
* **Standards:**
  * **IS 9873 (Part 1):** Mechanical and physical safety (choking hazards, sharp edges, drop tests).
  * **IS 9873 (Part 2 & 3):** Flammability and migration of non-toxic heavy metals.
  * **IS 15644:** Electrical safety for battery/remote-operated toys.
* **Scheme:** **Scheme-I (ISI Mark)** via [manakonline.in](https://www.manakonline.in).`,
    sources: [{ is_number: 'IS 9873-1:2019', title: 'Safety of Toys — Mechanical & Physical Safety', category: 'Toys & Playthings' }],
  },

  cooker: {
    answer: `### 🍲 Domestic Pressure Cookers — IS 2347:2017

* **Mandatory QCO:** Domestic Pressure Cookers (Quality Control) Order.
* **Scheme:** **Scheme-I (ISI Mark)** — mandatory factory inspection.
* **Safety Tests:**
  1. **Proof Pressure Test:** Vessel must withstand double the normal operating pressure without leakage.
  2. **Bursting Pressure Test:** Must withstand extreme pressures without rupture.
  3. **Safety Valve Release:** Fuse plug / spring valve must release pressure reliably.
* **Portal:** [manakonline.in](https://www.manakonline.in).`,
    sources: [{ is_number: 'IS 2347:2017', title: 'Domestic Pressure Cookers — Specification', category: 'Cookware & Pressure Vessels' }],
  },

  gold: {
    answer: `### 🥇 Gold Hallmarking & HUID — IS 1417:2016

* **Mandatory Status:** Compulsory across 256+ districts in India.
* **Authentic 3-Symbol Mark Structure:**
  1. **BIS Triangle Logo** (Bureau of Indian Standards emblem)
  2. **Purity & Karatage** (e.g. \`22K916\` for 91.6% pure gold, \`18K750\` for 75%, \`14K585\` for 58.5%)
  3. **6-Digit Laser HUID Number** (Unique alphanumeric code e.g. \`AZ78K2\`)
* **Fake Alert:** Outdated 4-mark jewelry (showing jeweller's logo or old assay mark without 6-digit HUID) is no longer valid for new sales.`,
    sources: [{ is_number: 'IS 1417:2016', title: 'Gold & Gold Alloys, Jewellery/Artefacts — Fineness & Hallmarking', category: 'Precious Metals' }],
  },

  cement_steel: {
    answer: `### 🏗️ Cement & TMT Steel Rebars — IS 1489 / IS 1786

* **Mandatory Status:** Strictly mandatory under Ministry of Industry & Commerce QCOs.
* **Standards:**
  * **Cement:** **IS 1489 (Part 1 & 2)** for Portland Pozzolana Cement (PPC) and **IS 12269** for 53 Grade OPC.
  * **TMT Steel:** **IS 1786:2008** for High Strength Deformed Steel Bars for Concrete Reinforcement.
* **Scheme:** **Scheme-I (ISI Mark)** with continuous factory quality control and batch testing.`,
    sources: [
      { is_number: 'IS 1489:2015', title: 'Portland Pozzolana Cement Specification', category: 'Civil & Construction' },
      { is_number: 'IS 1786:2008', title: 'High Strength Deformed Steel Bars for Concrete Reinforcement', category: 'Steel & Metallurgy' },
    ],
  },
};

export function getFallbackResponse(query: string): FallbackResponse | null {
  const q = query.toLowerCase();
  if (q.includes('helmet') || q.includes('4151') || q.includes('bike') || q.includes('rider')) return EXTENDED_FALLBACKS.helmet;
  if (q.includes('kettle') || q.includes('heater') || q.includes('iron') || q.includes('appliance') || q.includes('302')) return EXTENDED_FALLBACKS.kettle_appliances;
  if (q.includes('charger') || q.includes('adapter') || q.includes('mobile') || q.includes('led') || q.includes('crs') || q.includes('16333')) return EXTENDED_FALLBACKS.charger_electronics;
  if (q.includes('toy') || q.includes('9873') || q.includes('child') || q.includes('game')) return EXTENDED_FALLBACKS.toys;
  if (q.includes('cooker') || q.includes('2347') || q.includes('vessel')) return EXTENDED_FALLBACKS.cooker;
  if (q.includes('gold') || q.includes('jewel') || q.includes('huid') || q.includes('1417') || q.includes('hallmark')) return EXTENDED_FALLBACKS.gold;
  if (q.includes('cement') || q.includes('steel') || q.includes('tmt') || q.includes('bar') || q.includes('1786') || q.includes('1489')) return EXTENDED_FALLBACKS.cement_steel;
  return null;
}
